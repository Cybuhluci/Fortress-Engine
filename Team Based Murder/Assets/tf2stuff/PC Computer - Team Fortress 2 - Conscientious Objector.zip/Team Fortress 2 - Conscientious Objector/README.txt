TF2 Conscientious Objector ripped by NullNotBub
No credit needed. Ripped using Crowbar and VTFEdit.

Make sure to disable Show Backface when opening in Blender or similar software.