you dont HAVE to credit me, but i would like it if you did so.
Ported by Scientist from the vgresource.